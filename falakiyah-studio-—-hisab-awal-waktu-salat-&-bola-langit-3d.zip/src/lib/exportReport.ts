import type { DailyScheduleRow, HisabReport } from '../types/hisab';
import { formatLatDMS, formatLonDMS } from './hisabEngine';

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

export async function buildHisabDocxBlob(
  report: HisabReport,
  schedule: DailyScheduleRow[]
): Promise<Blob> {
  const docx = window.docx;
  if (!docx) {
    throw new Error('Pustaka docx (index.umd_02d568d2.js) belum termuat.');
  }

  const {
    Document,
    Packer,
    Paragraph,
    TextRun,
    Table,
    TableRow,
    TableCell,
    AlignmentType,
    HeadingLevel,
    WidthType,
    BorderStyle,
    ShadingType,
  } = docx;

  const { config } = report;
  const sourceLabel =
    report.ephemerisUsed === 'pdf_benchmark'
      ? 'Referensi Ephemeris Hisab Rukyat Depag RI (Benchmark PDF 2 Sept 2006)'
      : 'Ephemeris Astronomi Otomatis (CosineKitty Astronomy Engine)';

  const thinBorder = {
    style: BorderStyle.SINGLE,
    size: 4,
    color: 'CBD5E1',
  };

  const headerCell = (text: string, widthPct?: number) =>
    new TableCell({
      shading: { fill: '0F172A', type: ShadingType.CLEAR },
      borders: { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder },
      width: widthPct ? { size: widthPct, type: WidthType.PERCENTAGE } : undefined,
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 80, after: 80 },
          children: [
            new TextRun({
              text,
              bold: true,
              color: 'F8FAFC',
              size: 18,
              font: 'Calibri',
            }),
          ],
        }),
      ],
    });

  const bodyCell = (
    lines: string[],
    align: any = AlignmentType.LEFT,
    bold = false,
    fillHex?: string
  ) =>
    new TableCell({
      shading: fillHex ? { fill: fillHex, type: ShadingType.CLEAR } : undefined,
      borders: { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder },
      children: lines.map(
        (line) =>
          new Paragraph({
            alignment: align,
            spacing: { before: 50, after: 50 },
            children: [
              new TextRun({
                text: line,
                bold,
                size: 18,
                font: 'Calibri',
                color: '0F172A',
              }),
            ],
          })
      ),
    });

  // Page 4 Tabel Kerja Ringkas
  const kerjaRows = [
    new TableRow({
      tableHeader: true,
      children: [
        headerCell('Waktu', 10),
        headerCell('Data Astronomis', 22),
        headerCell('Sudut h', 13),
        headerCell('Sudut t / Jam t', 19),
        headerCell('Terbatas', 13),
        headerCell('WI', 11),
        headerCell('Standar', 12),
      ],
    }),
    ...report.prayers.map((p, idx) => {
      const fill = idx % 2 === 1 ? 'F8FAFC' : undefined;
      const dataLines =
        p.id === 'zuhur'
          ? [
              `e = ${report.equationOfTimeHMS} (${p.gmtSampleLabel})`,
              `SD = ${report.semiDiameterDMS}`,
            ]
          : [`δ = ${p.declinationDMS}`, `(${p.gmtSampleLabel})`];

      const tLines =
        p.id === 'zuhur'
          ? ['—', `Jam SD: ${p.jamTHMS}`]
          : [`t = ${p.hourAngleDMS ?? '—'}`, `Jam t = ${p.jamTHMS}`];

      return new TableRow({
        children: [
          bodyCell([p.name], AlignmentType.LEFT, true, fill),
          bodyCell(dataLines, AlignmentType.LEFT, false, fill),
          bodyCell([p.altitudeDMS ?? '—'], AlignmentType.CENTER, false, fill),
          bodyCell(tLines, AlignmentType.CENTER, false, fill),
          bodyCell([p.terbatasHMS], AlignmentType.CENTER, false, fill),
          bodyCell([p.ikhtiyatiHMS], AlignmentType.CENTER, false, fill),
          bodyCell([`${p.standarHHMM} ${config.timezoneLabel}`], AlignmentType.CENTER, true, fill),
        ],
      });
    }),
  ];

  // 30-day schedule table
  const monthlyRows = [
    new TableRow({
      tableHeader: true,
      children: [
        headerCell('Hari', 6),
        headerCell('Tanggal', 18),
        headerCell('Imsak', 11),
        headerCell('Subuh', 11),
        headerCell('Terbit', 11),
        headerCell('Zuhur', 11),
        headerCell('Asar', 11),
        headerCell('Magrib', 11),
        headerCell('Isyak', 10),
      ],
    }),
    ...schedule.map((row, idx) => {
      const fill = idx % 2 === 1 ? 'F8FAFC' : undefined;
      return new TableRow({
        children: [
          bodyCell([String(row.dayIndex)], AlignmentType.CENTER, false, fill),
          bodyCell([row.dateLabel], AlignmentType.LEFT, false, fill),
          bodyCell([row.imsak], AlignmentType.CENTER, false, fill),
          bodyCell([row.subuh], AlignmentType.CENTER, true, fill),
          bodyCell([row.terbit], AlignmentType.CENTER, false, fill),
          bodyCell([row.zuhur], AlignmentType.CENTER, true, fill),
          bodyCell([row.asar], AlignmentType.CENTER, true, fill),
          bodyCell([row.magrib], AlignmentType.CENTER, true, fill),
          bodyCell([row.isyak], AlignmentType.CENTER, true, fill),
        ],
      });
    }),
  ];

  const detailParagraphs = report.prayers.flatMap((p) => [
    new Paragraph({
      spacing: { before: 160, after: 60 },
      children: [
        new TextRun({
          text: `• Awal ${p.name}`,
          bold: true,
          size: 22,
          color: '0F172A',
        }),
        new TextRun({
          text: `  (${p.gmtSampleLabel}) — Standar: ${p.standarHHMM} ${config.timezoneLabel}`,
          bold: true,
          size: 20,
          color: '1D4ED8',
        }),
      ],
    }),
    ...p.formulaSteps.map(
      (step) =>
        new Paragraph({
          indent: { left: 360 },
          spacing: { before: 20, after: 30 },
          children: [
            new TextRun({
              text: step,
              size: 19,
              font: 'Consolas',
              color: '334155',
            }),
          ],
        })
    ),
  ]);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: { top: 900, right: 900, bottom: 900, left: 900 },
          },
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 60 },
            children: [
              new TextRun({
                text: 'HISAB AWAL WAKTU SALAT',
                bold: true,
                size: 32,
                color: '0F172A',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 220 },
            children: [
              new TextRun({
                text: `Metode Abd. Salam Nawawi (hlm. 24–35) · ${sourceLabel}`,
                italics: true,
                size: 20,
                color: '475569',
              }),
            ],
          }),
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 120, after: 80 },
            children: [
              new TextRun({
                text: 'A. Data Dasar Markaz & Waktu',
                bold: true,
                size: 24,
                color: '0F172A',
              }),
            ],
          }),
          ...[
            `Markaz: ${config.locationName} (φ = ${formatLatDMS(config.latitudeDeg)}, λ = ${formatLonDMS(config.longitudeDeg)}, ketinggian = ${config.elevationM} m)`,
            `Tanggal Hisab: ${config.dateISO} · Zona Waktu: ${config.timezoneLabel} (λ_Zona = ${config.timezoneMeridianDeg}° BT, GMT+${config.timezoneOffsetHours})`,
            `Kerendahan Ufuk (D′ untuk ${config.elevationM} m): (1.76′ × √${config.elevationM}) / 60 = ${report.dipDMS}`,
            `Koreksi Waktu Daerah (kwd): (${config.timezoneMeridianDeg}° − ${formatLonDMS(config.longitudeDeg)}) / 15 = ${report.kwdHMS}`,
            `Data Ephemeris Pukul Kulminasi: e = ${report.equationOfTimeHMS} dan SD = ${report.semiDiameterDMS}`,
            `Waktu Kulminasi Matahari (WKM): 12 − e + kwd = ${report.wkmHMS} ${config.timezoneLabel}`,
            `Waktu Bantu Tambahan: Imsak = ${report.imsakHHMM} ${config.timezoneLabel} · Terbit (Syuruq) = ${report.terbitHHMM} ${config.timezoneLabel}`,
          ].map(
            (text) =>
              new Paragraph({
                spacing: { before: 30, after: 40 },
                indent: { left: 240 },
                children: [new TextRun({ text: `• ${text}`, size: 20, color: '1E293B' })],
              })
          ),
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 200, after: 80 },
            children: [
              new TextRun({
                text: 'B. Rincian Perhitungan Setiap Waktu Salat',
                bold: true,
                size: 24,
                color: '0F172A',
              }),
            ],
          }),
          ...detailParagraphs,
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 260, after: 100 },
            children: [
              new TextRun({
                text: `C. Tabel Kerja Ringkas Seluruh Waktu Salat (${config.dateISO})`,
                bold: true,
                size: 24,
                color: '0F172A',
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: kerjaRows,
          }),
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 280, after: 100 },
            children: [
              new TextRun({
                text: `D. Jadwal Awal Waktu Salat 30 Hari (${config.locationName}, ${config.timezoneLabel})`,
                bold: true,
                size: 24,
                color: '0F172A',
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: monthlyRows,
          }),
        ],
      },
    ],
  });

  return await Packer.toBlob(doc);
}

export async function downloadHisabDocx(
  report: HisabReport,
  schedule: DailyScheduleRow[]
): Promise<void> {
  const blob = await buildHisabDocxBlob(report, schedule);
  const filename = `Laporan_Hisab_${slugify(report.config.locationName)}_${report.config.dateISO}.docx`;
  triggerDownload(blob, filename);
}

export function buildScheduleCSV(report: HisabReport, schedule: DailyScheduleRow[]): string {
  const header = [
    'Hari',
    'Tanggal',
    'ISO',
    'Deklinasi_Matahari',
    'Perata_Waktu_e',
    `Imsak_${report.config.timezoneLabel}`,
    `Subuh_${report.config.timezoneLabel}`,
    `Terbit_${report.config.timezoneLabel}`,
    `Zuhur_${report.config.timezoneLabel}`,
    `Asar_${report.config.timezoneLabel}`,
    `Magrib_${report.config.timezoneLabel}`,
    `Isyak_${report.config.timezoneLabel}`,
  ].join(',');

  const lines = schedule.map((r) =>
    [
      r.dayIndex,
      `"${r.dateLabel}"`,
      r.dateISO,
      `"${r.declinationDMS}"`,
      `"${r.equationOfTimeHMS}"`,
      r.imsak,
      r.subuh,
      r.terbit,
      r.zuhur,
      r.asar,
      r.magrib,
      r.isyak,
    ].join(',')
  );

  // UTF-8 BOM so Excel parses degree/prime symbols cleanly
  return '\uFEFF' + [header, ...lines].join('\n');
}

export async function downloadHisabZipBundle(
  report: HisabReport,
  schedule: DailyScheduleRow[]
): Promise<void> {
  const JSZip = window.JSZip;
  if (!JSZip) {
    throw new Error('Pustaka JSZip (jszip.min_acc7e414.js) belum termuat.');
  }

  const zip = new JSZip();
  const slug = `${slugify(report.config.locationName)}_${report.config.dateISO}`;

  const docxBlob = await buildHisabDocxBlob(report, schedule);
  zip.file(`Laporan_Hisab_${slug}.docx`, docxBlob);
  zip.file(`Jadwal_Salat_30_Hari_${slug}.csv`, buildScheduleCSV(report, schedule));
  zip.file(
    `Data_Ephemeris_Hisab_${slug}.json`,
    JSON.stringify({ report, schedule }, null, 2)
  );

  const formulaLog = [
    'HISAB AWAL WAKTU SALAT — AUDIT LOG RUMUS FALAK',
    `Markaz: ${report.config.locationName}`,
    `Koordinat: ${formatLatDMS(report.config.latitudeDeg)}, ${formatLonDMS(report.config.longitudeDeg)}, Elevasi ${report.config.elevationM} m`,
    `Tanggal: ${report.config.dateISO} (${report.config.timezoneLabel})`,
    `D' = ${report.dipDMS} | kwd = ${report.kwdHMS} | e = ${report.equationOfTimeHMS} | SD = ${report.semiDiameterDMS} | WKM = ${report.wkmHMS}`,
    '',
    ...report.prayers.flatMap((p) => [
      `[${p.name.toUpperCase()}] (${p.gmtSampleLabel}) -> Standar: ${p.standarHHMM} ${report.config.timezoneLabel}`,
      ...p.formulaSteps.map((s) => `  - ${s}`),
      '',
    ]),
  ].join('\n');

  zip.file(`Ringkasan_Perhitungan_${slug}.txt`, formulaLog);

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  triggerDownload(zipBlob, `Paket_Hisab_Falak_${slug}.zip`);
}

export type EphemerisSource = 'astronomy_engine' | 'pdf_benchmark';

export type AsarMethod = 'syafii' | 'hanafi';

export type IkhtiyatiMode = 'nawawi_1_2' | 'fixed_2_min';

export type PrayerId = 'subuh' | 'terbit' | 'zuhur' | 'asar' | 'magrib' | 'isyak';

export interface MarkazPreset {
  id: string;
  name: string;
  region: string;
  latitudeDeg: number; // Negative = LS, Positive = LU
  longitudeDeg: number; // Positive = BT
  elevationM: number;
  timezoneOffsetHours: number; // e.g., 7 for WIB, 8 for WITA, 9 for WIT
  timezoneLabel: string; // e.g., "WIB", "WITA", "WIT"
  timezoneMeridianDeg: number; // e.g., 105, 120, 135
}

export interface HisabInputConfig {
  locationName: string;
  dateISO: string; // YYYY-MM-DD
  latitudeDeg: number;
  longitudeDeg: number;
  elevationM: number;
  timezoneOffsetHours: number;
  timezoneLabel: string;
  timezoneMeridianDeg: number;
  ephemerisSource: EphemerisSource;
  subuhDepressionDeg: number; // default 20 (Depag RI), options: 18, 18.5, 19, 20
  isyakDepressionDeg: number; // default 18 (Depag RI), options: 17, 18, 19
  asarMethod: AsarMethod; // syafii (1x) or hanafi (2x)
  ikhtiyatiMode: IkhtiyatiMode;
}

export interface PrayerCalculationDetail {
  id: 'zuhur' | 'subuh' | 'asar' | 'magrib' | 'isyak';
  name: string;
  gmtSampleLabel: string;
  gmtDateISO: string;
  declinationDeg: number; // delta
  declinationDMS: string;
  zmDeg?: number; // |phi - delta| for Asar
  zmDMS?: string;
  cotHAsar?: number;
  altitudeDeg?: number; // h
  altitudeDMS?: string;
  cosT?: number;
  hourAngleDeg?: number; // t in degrees
  hourAngleDMS?: string;
  jamTHours: number; // t/15 or SD/15 for Zuhur
  jamTHMS: string;
  terbatasHours: number; // local decimal hours
  terbatasHMS: string;
  ikhtiyatiHours: number; // WI added
  ikhtiyatiHMS: string;
  standarHours: number; // rounded integer minute
  standarHHMM: string;
  formulaSteps: string[];
  astronomicalNote: string;
}

export interface HisabReport {
  config: HisabInputConfig;
  ephemerisUsed: EphemerisSource;
  dipDeg: number; // D' = (1.76 * sqrt(h)) / 60
  dipDMS: string;
  kwdHours: number; // (lambda_zone - lambda_markaz) / 15
  kwdHMS: string;
  equationOfTimeHours: number; // e
  equationOfTimeHMS: string;
  semiDiameterDeg: number; // SD
  semiDiameterDMS: string;
  wkmHours: number; // 12 - e + kwd
  wkmHMS: string;
  terbitHours: number; // Sunrise (h = -0°50.5' - D') before WKM
  terbitHHMM: string;
  imsakHours: number; // Subuh - 10 min
  imsakHHMM: string;
  prayers: PrayerCalculationDetail[];
}

export interface DailyScheduleRow {
  dayIndex: number;
  dateISO: string;
  dateLabel: string;
  imsak: string;
  subuh: string;
  terbit: string;
  zuhur: string;
  asar: string;
  magrib: string;
  isyak: string;
  declinationDMS: string;
  equationOfTimeHMS: string;
}

export interface SkyStateAtTime {
  localHours: number;
  localHMS: string;
  declinationDeg: number;
  equationOfTimeHours: number;
  hourAngleDeg: number; // positive = West (after WKM), negative = East (before WKM)
  altitudeDeg: number; // true geometric center altitude above horizon
  apparentAltitudeDeg: number; // including refraction approximation near horizon
  azimuthDeg: number; // 0 = North, 90 = East, 180 = South, 270 = West
  gnomonShadowLengthRatio: number | null; // tan(zenith distance) if altitude > 0.5 deg
  gnomonCulminationShadowRatio: number; // tan(|phi - delta|)
  asarShadowThresholdRatio: number; // tan(|phi - delta|) + 1 (or +2)
  phaseLabel: string;
}

declare global {
  interface Window {
    THREE: any;
    Astronomy: any;
    docx: any;
    JSZip: any;
  }
}

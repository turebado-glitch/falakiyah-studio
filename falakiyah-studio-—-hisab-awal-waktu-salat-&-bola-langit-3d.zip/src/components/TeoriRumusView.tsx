import React from 'react';
import type { HisabReport } from '../types/hisab';

interface TeoriRumusViewProps {
  report: HisabReport;
}

export const TeoriRumusView: React.FC<TeoriRumusViewProps> = ({ report }) => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Architecture Summary of the 6 Integrated Assets */}
      <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-5">
        <h2 className="font-serif text-lg font-semibold text-slate-100">
          Arsitektur Pemaduan Enam Komponen
        </h2>
        <p className="mt-1 text-xs text-slate-400">
          Seluruh berkas risalah falak, mesin astronomi, visualisasi WebGL 3D, dan generator dokumen
          bekerja langsung dalam satu alur terpadu.
        </p>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {[
            {
              file: 'Rangkuman_Hisab_Awal_Waktu_Salat_109596df.pdf',
              role: 'Metodologi & Rumus Falakiyah',
              detail:
                'Persamaan D′, kwd, WKM, cot h Asar, sudut waktu cos t, dan pembulatan Ikhtiyati 1–2 menit (Abd. Salam Nawawi, hlm. 24–35).',
            },
            {
              file: 'astronomy.browser_a2cfab19.js',
              role: 'Mesin Ephemeris Otomatis',
              detail:
                'Menghitung deklinasi sejati Matahari (δ), perata waktu (e), dan semi-diameter (SD) untuk tanggal, jam GMT, dan koordinat mana pun.',
            },
            {
              file: 'three.min_9274bbce.js',
              role: 'Renderer Bola Langit 3D (r128)',
              detail:
                'Membangun Bola Langit, lintasan harian Matahari, kerendahan ufuk D′, cincin fajar/syafaq (−18°/−20°), dan bayangan Tongkat Istiwa.',
            },
            {
              file: 'OrbitControls_02bb4ade.js',
              role: 'Navigasi Kamera Interaktif',
              detail:
                'Memungkinkan inspeksi 360° sudut t, sudut h, meridian, dan panjang bayangan gnomon dengan damping halus.',
            },
            {
              file: 'index.umd_02d568d2.js',
              role: 'Generator Laporan Microsoft Word (.docx)',
              detail:
                'Menyusun dokumen laporan lengkap berisi Data Dasar, Rincian Perhitungan, Tabel Kerja Ringkas, dan Jadwal 30 Hari.',
            },
            {
              file: 'jszip.min_acc7e414.js',
              role: 'Pengemas Arsip Laporan (.zip)',
              detail:
                'Menggabungkan laporan .docx, jadwal .csv, telemetri ephemeris .json, dan catatan rumus ke dalam satu paket unduhan.',
            },
          ].map((item) => (
            <div
              key={item.file}
              className="rounded-lg border border-slate-800 bg-slate-900/50 p-3.5"
            >
              <div className="font-semibold text-amber-300">{item.role}</div>
              <div className="mt-0.5 font-mono text-[10px] text-slate-400 break-all">
                {item.file}
              </div>
              <p className="mt-2 text-slate-300 leading-relaxed">{item.detail}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Treatise Reference & Live Comparison */}
      <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-5 space-y-5">
        <div className="border-b border-slate-800 pb-3">
          <h2 className="font-serif text-lg font-semibold text-slate-100">
            Ringkasan Rumus Hisab Awal Waktu Salat (Abd. Salam Nawawi, hlm. 24–35)
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Disandingkan langsung dengan hasil hitungan aktif untuk Markaz{' '}
            <strong className="text-slate-200">{report.config.locationName}</strong> ({report.config.dateISO}).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <h3 className="font-semibold text-slate-100">1. Kerendahan Ufuk (D′)</h3>
            <p className="text-slate-400">
              Koreksi akibat ketinggian tempat di atas permukaan laut (h dalam meter):
            </p>
            <div className="rounded bg-slate-950 p-2.5 font-mono text-amber-300">
              D′ = (1.76′ × √h) / 60
            </div>
            <div className="font-mono text-slate-300 tabular-nums">
              Nilai Aktif ({report.config.elevationM} m) ⇒{' '}
              <strong className="text-slate-100">{report.dipDMS}</strong>
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <h3 className="font-semibold text-slate-100">
              2. Koreksi Waktu Daerah (kwd) &amp; WKM
            </h3>
            <p className="text-slate-400">
              Konversi Waktu Hakiki (12:00) ke Waktu Pertengahan Daerah:
            </p>
            <div className="rounded bg-slate-950 p-2.5 font-mono text-amber-300">
              kwd = (λ_Zona − λ_Markaz) / 15 · WKM = 12 − e + kwd
            </div>
            <div className="font-mono text-slate-300 tabular-nums">
              kwd = {report.kwdHMS} · WKM ={' '}
              <strong className="text-slate-100">
                {report.wkmHMS} {report.config.timezoneLabel}
              </strong>
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <h3 className="font-semibold text-slate-100">3. Sudut Waktu Matahari (t)</h3>
            <p className="text-slate-400">
              Hubungan lintang φ, deklinasi δ, dan ketinggian pusat Matahari h:
            </p>
            <div className="rounded bg-slate-950 p-2.5 font-mono text-sky-300">
              cos t = −tan φ · tan δ + sin h / (cos φ · cos δ), Jam t = t / 15
            </div>
            <p className="text-slate-400">
              Subuh: WKM − Jam t · Asar, Magrib, Isyak: WKM + Jam t · Zuhur: WKM + SD/15.
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <h3 className="font-semibold text-slate-100">
              4. Kriteria Ketinggian Matahari (h)
            </h3>
            <ul className="space-y-1.5 font-mono text-[11px] text-slate-300">
              <li>• Subuh : h = 0° − {report.config.subuhDepressionDeg}° − D′ (Fajar Shadiq)</li>
              <li>
                • Asar  : cot h = tan |φ − δ| +{' '}
                {report.config.asarMethod === 'hanafi' ? '2 (Hanafi)' : '1 (Jumhur)'}
              </li>
              <li>• Magrib: h = 0° − 34.5′ (Refr) − 16′ (SD) − D′ = −50.5′ − D′</li>
              <li>• Isyak : h = 0° − {report.config.isyakDepressionDeg}° − D′ (Syafaq Merah)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

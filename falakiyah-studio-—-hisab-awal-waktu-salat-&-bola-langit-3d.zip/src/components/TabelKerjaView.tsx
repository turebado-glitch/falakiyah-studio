import React from 'react';
import { Archive, FileSpreadsheet, FileText } from 'lucide-react';
import type { DailyScheduleRow, HisabReport } from '../types/hisab';

interface TabelKerjaViewProps {
  report: HisabReport;
  schedule: DailyScheduleRow[];
  onExportDocx: () => void;
  onExportZip: () => void;
  onExportCsv: () => void;
  exportBusy: boolean;
}

export const TabelKerjaView: React.FC<TabelKerjaViewProps> = ({
  report,
  schedule,
  onExportDocx,
  onExportZip,
  onExportCsv,
  exportBusy,
}) => {
  const { config } = report;

  return (
    <div className="space-y-6">
      {/* Page 4 Tabel Kerja Ringkas Seluruh Waktu Salat */}
      <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h2 className="font-serif text-lg font-semibold text-slate-100">
              Tabel Kerja Ringkas Seluruh Waktu Salat ({config.dateISO})
            </h2>
            <p className="text-xs text-slate-400">
              Format ringkasan halaman 4 risalah Abd. Salam Nawawi · Markaz {config.locationName}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={exportBusy}
              onClick={onExportDocx}
              className="flex items-center gap-1.5 rounded-lg border border-amber-500/60 bg-amber-500/15 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/25 disabled:opacity-50"
            >
              <FileText className="h-3.5 w-3.5" />
              Unduh Laporan DOCX
            </button>
            <button
              type="button"
              disabled={exportBusy}
              onClick={onExportCsv}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500 disabled:opacity-50"
            >
              <FileSpreadsheet className="h-3.5 w-3.5" />
              Unduh CSV 30 Hari
            </button>
            <button
              type="button"
              disabled={exportBusy}
              onClick={onExportZip}
              className="flex items-center gap-1.5 rounded-lg border border-sky-500/60 bg-sky-500/15 px-3 py-1.5 text-xs font-semibold text-sky-200 hover:bg-sky-500/25 disabled:opacity-50"
            >
              <Archive className="h-3.5 w-3.5" />
              Paket Arsip ZIP (DOCX + CSV + JSON)
            </button>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-700 bg-slate-900/70 text-[11px] uppercase tracking-wider text-slate-300">
                <th className="px-3 py-2.5 font-semibold">Waktu</th>
                <th className="px-3 py-2.5 font-semibold">Data Astronomis</th>
                <th className="px-3 py-2.5 font-semibold text-right">Sudut h</th>
                <th className="px-3 py-2.5 font-semibold text-right">Sudut t / Jam t</th>
                <th className="px-3 py-2.5 font-semibold text-right">Terbatas</th>
                <th className="px-3 py-2.5 font-semibold text-right">WI</th>
                <th className="px-3 py-2.5 font-semibold text-right">Standar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono tabular-nums">
              {report.prayers.map((p) => (
                <tr key={p.id} className="hover:bg-slate-900/40">
                  <td className="px-3 py-3 font-sans font-semibold text-slate-100">{p.name}</td>
                  <td className="px-3 py-3 text-slate-300">
                    {p.id === 'zuhur' ? (
                      <div className="space-y-0.5">
                        <div>
                          e = {report.equationOfTimeHMS} ({p.gmtSampleLabel})
                        </div>
                        <div className="text-slate-400">SD = {report.semiDiameterDMS}</div>
                      </div>
                    ) : (
                      <div className="space-y-0.5">
                        <div>δ = {p.declinationDMS}</div>
                        <div className="text-slate-400">({p.gmtSampleLabel})</div>
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-3 text-right text-slate-200">
                    {p.altitudeDMS ?? '—'}
                  </td>
                  <td className="px-3 py-3 text-right text-slate-200">
                    {p.id === 'zuhur' ? (
                      <div>
                        <span className="text-slate-500">—</span> · {p.jamTHMS}
                      </div>
                    ) : (
                      <div>
                        <div>{p.hourAngleDMS}</div>
                        <div className="text-slate-400">{p.jamTHMS}</div>
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-3 text-right text-slate-200">{p.terbatasHMS}</td>
                  <td className="px-3 py-3 text-right text-slate-400">{p.ikhtiyatiHMS}</td>
                  <td className="px-3 py-3 text-right font-bold text-amber-300">
                    {p.standarHHMM} {config.timezoneLabel}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 30-Day Prayer Schedule Table */}
      <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4 sm:p-5">
        <div className="pb-3 border-b border-slate-800 flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h3 className="font-serif text-base font-semibold text-slate-100">
              Jadwal Awal Waktu Salat 30 Hari ({config.locationName})
            </h3>
            <p className="text-xs text-slate-400">
              Dihitung otomatis per hari menggunakan Astronomy Engine mulai {config.dateISO} ({config.timezoneLabel})
            </p>
          </div>
          <span className="font-mono text-[11px] text-slate-400">
            Subuh −{config.subuhDepressionDeg}° · Isyak −{config.isyakDepressionDeg}° · Asar{' '}
            {config.asarMethod === 'syafii' ? 'Jumhur' : 'Hanafi'}
          </span>
        </div>

        <div className="mt-3 overflow-x-auto max-h-[460px] overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-900 z-10 border-b border-slate-700 text-[11px] uppercase tracking-wider text-slate-300">
              <tr>
                <th className="px-2.5 py-2">Hari</th>
                <th className="px-2.5 py-2">Tanggal</th>
                <th className="px-2.5 py-2 text-right">Deklinasi δ</th>
                <th className="px-2.5 py-2 text-right text-sky-300">Imsak</th>
                <th className="px-2.5 py-2 text-right">Subuh</th>
                <th className="px-2.5 py-2 text-right text-slate-400">Terbit</th>
                <th className="px-2.5 py-2 text-right">Zuhur</th>
                <th className="px-2.5 py-2 text-right">Asar</th>
                <th className="px-2.5 py-2 text-right">Magrib</th>
                <th className="px-2.5 py-2 text-right">Isyak</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
              {schedule.map((row) => (
                <tr key={row.dateISO} className="hover:bg-slate-900/50">
                  <td className="px-2.5 py-2 text-slate-500">{row.dayIndex}</td>
                  <td className="px-2.5 py-2 font-sans text-slate-200 whitespace-nowrap">
                    {row.dateLabel}
                  </td>
                  <td className="px-2.5 py-2 text-right text-slate-400">{row.declinationDMS}</td>
                  <td className="px-2.5 py-2 text-right text-sky-300">{row.imsak}</td>
                  <td className="px-2.5 py-2 text-right font-semibold text-slate-100">{row.subuh}</td>
                  <td className="px-2.5 py-2 text-right text-slate-400">{row.terbit}</td>
                  <td className="px-2.5 py-2 text-right font-semibold text-amber-300">{row.zuhur}</td>
                  <td className="px-2.5 py-2 text-right font-semibold text-slate-100">{row.asar}</td>
                  <td className="px-2.5 py-2 text-right font-semibold text-rose-300">{row.magrib}</td>
                  <td className="px-2.5 py-2 text-right font-semibold text-slate-100">{row.isyak}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

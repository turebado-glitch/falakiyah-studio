import React from 'react';
import { Compass, Crosshair, Box } from 'lucide-react';
import type {
  AsarMethod,
  EphemerisSource,
  HisabInputConfig,
  HisabReport,
  IkhtiyatiMode,
} from '../types/hisab';
import {
  MARKAZ_PRESETS,
  formatLatDMS,
  formatLonDMS,
} from '../lib/hisabEngine';

interface RincianHisabViewProps {
  config: HisabInputConfig;
  report: HisabReport;
  onChangeConfig: (updater: (prev: HisabInputConfig) => HisabInputConfig) => void;
  onInspectIn3D: (localHours: number) => void;
}

export const RincianHisabView: React.FC<RincianHisabViewProps> = ({
  config,
  report,
  onChangeConfig,
  onInspectIn3D,
}) => {
  const [geoStatus, setGeoStatus] = React.useState<string | null>(null);

  const handlePresetSelect = (presetId: string) => {
    const preset = MARKAZ_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    onChangeConfig((prev) => ({
      ...prev,
      locationName: preset.name,
      latitudeDeg: preset.latitudeDeg,
      longitudeDeg: preset.longitudeDeg,
      elevationM: preset.elevationM,
      timezoneOffsetHours: preset.timezoneOffsetHours,
      timezoneLabel: preset.timezoneLabel,
      timezoneMeridianDeg: preset.timezoneMeridianDeg,
      dateISO: preset.id === 'surabaya-pdf' ? '2006-09-02' : prev.dateISO,
      ephemerisSource:
        preset.id === 'surabaya-pdf' ? prev.ephemerisSource : 'astronomy_engine',
    }));
  };

  const handleUseGeolocation = () => {
    if (!navigator.geolocation) {
      setGeoStatus('Geolokasi tidak didukung peramban.');
      return;
    }
    setGeoStatus('Mengambil koordinat GPS…');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, altitude } = pos.coords;
        const tzHours = Math.round(longitude / 15);
        const tzMeridian = tzHours * 15;
        const tzLabel =
          tzHours === 7
            ? 'WIB'
            : tzHours === 8
              ? 'WITA'
              : tzHours === 9
                ? 'WIT'
                : `UTC${tzHours >= 0 ? '+' : ''}${tzHours}`;
        onChangeConfig((prev) => ({
          ...prev,
          locationName: 'Lokasi GPS Saat Ini',
          latitudeDeg: Number(latitude.toFixed(5)),
          longitudeDeg: Number(longitude.toFixed(5)),
          elevationM: altitude ? Math.max(0, Math.round(altitude)) : prev.elevationM,
          timezoneOffsetHours: tzHours,
          timezoneMeridianDeg: tzMeridian,
          timezoneLabel: tzLabel,
          ephemerisSource: 'astronomy_engine',
        }));
        setGeoStatus(null);
      },
      () => {
        setGeoStatus('Izin geolokasi ditolak atau gagal membaca posisi.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleTimezonePreset = (tzHours: number) => {
    const labelMap: Record<number, string> = { 7: 'WIB', 8: 'WITA', 9: 'WIT' };
    onChangeConfig((prev) => ({
      ...prev,
      timezoneOffsetHours: tzHours,
      timezoneMeridianDeg: tzHours * 15,
      timezoneLabel: labelMap[tzHours] ?? `UTC${tzHours >= 0 ? '+' : ''}${tzHours}`,
    }));
  };

  const isPdfActive = report.ephemerisUsed === 'pdf_benchmark';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left Control Column */}
      <aside className="lg:col-span-4 space-y-4">
        <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Compass className="h-4 w-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-slate-100">
                Parameter Markaz &amp; Waktu
              </h2>
            </div>
            <button
              type="button"
              onClick={handleUseGeolocation}
              className="flex items-center gap-1 rounded border border-slate-700 bg-slate-900 px-2 py-1 text-[11px] font-medium text-slate-300 hover:border-amber-500/60 hover:text-amber-300"
            >
              <Crosshair className="h-3 w-3" />
              GPS
            </button>
          </div>

          {geoStatus && <p className="mt-2 text-xs text-amber-400">{geoStatus}</p>}

          <div className="mt-3 space-y-3">
            <div>
              <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">
                Preset Markaz
              </label>
              <select
                value={
                  MARKAZ_PRESETS.find(
                    (p) =>
                      Math.abs(p.latitudeDeg - config.latitudeDeg) < 0.001 &&
                      Math.abs(p.longitudeDeg - config.longitudeDeg) < 0.001
                  )?.id ?? ''
                }
                onChange={(e) => handlePresetSelect(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
              >
                <option value="" disabled>
                  Pilih kota atau ubah manual…
                </option>
                {MARKAZ_PRESETS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.region})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">
                  Nama Markaz
                </label>
                <input
                  type="text"
                  value={config.locationName}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({ ...prev, locationName: e.target.value }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">
                  Tanggal Hisab
                </label>
                <input
                  type="date"
                  value={config.dateISO}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      dateISO: e.target.value,
                      ephemerisSource:
                        e.target.value === '2006-09-02' ? prev.ephemerisSource : 'astronomy_engine',
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 font-mono text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Lintang φ (°)
                </label>
                <input
                  type="number"
                  step="0.001"
                  min={-66}
                  max={66}
                  value={Number(config.latitudeDeg.toFixed(5))}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      latitudeDeg: Number(e.target.value) || 0,
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-100 tabular-nums focus:border-amber-500 focus:outline-none"
                />
                <div className="mt-0.5 font-mono text-[10px] text-slate-500 tabular-nums">
                  {formatLatDMS(config.latitudeDeg)}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Bujur λ (°)
                </label>
                <input
                  type="number"
                  step="0.001"
                  min={-180}
                  max={180}
                  value={Number(config.longitudeDeg.toFixed(5))}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      longitudeDeg: Number(e.target.value) || 0,
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-100 tabular-nums focus:border-amber-500 focus:outline-none"
                />
                <div className="mt-0.5 font-mono text-[10px] text-slate-500 tabular-nums">
                  {formatLonDMS(config.longitudeDeg)}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Elevasi (m)
                </label>
                <input
                  type="number"
                  step="1"
                  min={0}
                  max={6000}
                  value={config.elevationM}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      elevationM: Math.max(0, Number(e.target.value) || 0),
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-100 tabular-nums focus:border-amber-500 focus:outline-none"
                />
                <div className="mt-0.5 font-mono text-[10px] text-slate-500 tabular-nums">
                  D′ {report.dipDMS}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1">
                Zona Waktu (λ Daerah)
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { h: 7, label: 'WIB · 105°' },
                  { h: 8, label: 'WITA · 120°' },
                  { h: 9, label: 'WIT · 135°' },
                ].map((tz) => (
                  <button
                    key={tz.h}
                    type="button"
                    onClick={() => handleTimezonePreset(tz.h)}
                    className={`rounded-lg border px-2 py-1.5 font-mono text-[11px] transition-colors ${
                      config.timezoneOffsetHours === tz.h
                        ? 'border-amber-500 bg-amber-500/15 text-amber-300 font-semibold'
                        : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {tz.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Ephemeris Source Switch */}
            <div className="pt-2 border-t border-slate-800">
              <label className="block text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-1.5">
                Sumber Data Ephemeris
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {(
                  [
                    {
                      id: 'astronomy_engine',
                      title: 'Astronomy Engine Otomatis (Semua Tanggal)',
                      desc: 'Hitung δ, e, dan SD secara langsung via astronomi posisi Matahari',
                    },
                    {
                      id: 'pdf_benchmark',
                      title: 'Data Ephemeris PDF (Benchmark 2 Sept 2006)',
                      desc: 'Gunakan nilai tepat tabel Ephemeris Depag RI pada buku hlm. 24–35',
                    },
                  ] as { id: EphemerisSource; title: string; desc: string }[]
                ).map((src) => {
                  const active =
                    src.id === 'pdf_benchmark' ? isPdfActive : !isPdfActive;
                  return (
                    <button
                      key={src.id}
                      type="button"
                      onClick={() => {
                        if (src.id === 'pdf_benchmark') {
                          handlePresetSelect('surabaya-pdf');
                        }
                        onChangeConfig((prev) => ({
                          ...prev,
                          ephemerisSource: src.id,
                          dateISO: src.id === 'pdf_benchmark' ? '2006-09-02' : prev.dateISO,
                        }));
                      }}
                      className={`rounded-lg border p-2.5 text-left transition-colors ${
                        active
                          ? 'border-sky-500/70 bg-sky-500/10'
                          : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-xs font-semibold text-slate-100">{src.title}</div>
                      <div className="mt-0.5 text-[11px] text-slate-400">{src.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Fiqh / Criterion Angles */}
            <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Sudut Subuh (h₀)
                </label>
                <select
                  value={config.subuhDepressionDeg}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      subuhDepressionDeg: Number(e.target.value),
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  <option value={20}>−20° (Depag RI)</option>
                  <option value={19}>−19°</option>
                  <option value={18.5}>−18.5°</option>
                  <option value={18}>−18° (MWL)</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Sudut Isyak (h₀)
                </label>
                <select
                  value={config.isyakDepressionDeg}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      isyakDepressionDeg: Number(e.target.value),
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  <option value={18}>−18° (Depag RI)</option>
                  <option value={17}>−17°</option>
                  <option value={19}>−19°</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Mazhab Asar
                </label>
                <select
                  value={config.asarMethod}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      asarMethod: e.target.value as AsarMethod,
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  <option value="syafii">Jumhur (tan zm + 1)</option>
                  <option value="hanafi">Hanafi (tan zm + 2)</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Ikhtiyati (WI)
                </label>
                <select
                  value={config.ikhtiyatiMode}
                  onChange={(e) =>
                    onChangeConfig((prev) => ({
                      ...prev,
                      ikhtiyatiMode: e.target.value as IkhtiyatiMode,
                    }))
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
                >
                  <option value="nawawi_1_2">1–2 mnt (Nawawi)</option>
                  <option value="fixed_2_min">+2 mnt Penuh</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Right Results & Detailed Derivation Column */}
      <section className="lg:col-span-8 space-y-5">
        {/* Prayer Standar Cards Grid */}
        <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2 pb-3 border-b border-slate-800">
            <div>
              <h2 className="font-serif text-lg font-semibold text-slate-100">
                Jadwal Awal Waktu Salat — {config.locationName}
              </h2>
              <p className="text-xs text-slate-400">
                {config.dateISO} · {formatLatDMS(config.latitudeDeg)} ·{' '}
                {formatLonDMS(config.longitudeDeg)} · Elevasi {config.elevationM} m ·{' '}
                {isPdfActive ? 'Ephemeris PDF (2 Sept 2006)' : 'CosineKitty Astronomy Engine'}
              </p>
            </div>
            <div className="font-mono text-xs text-slate-400 tabular-nums">
              Imsak <strong className="text-sky-300">{report.imsakHHMM}</strong> · Terbit{' '}
              <strong className="text-slate-200">{report.terbitHHMM}</strong> {config.timezoneLabel}
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {[
              report.prayers.find((p) => p.id === 'subuh')!,
              report.prayers.find((p) => p.id === 'zuhur')!,
              report.prayers.find((p) => p.id === 'asar')!,
              report.prayers.find((p) => p.id === 'magrib')!,
              report.prayers.find((p) => p.id === 'isyak')!,
            ].map((p) => (
              <div
                key={p.id}
                className="flex flex-col justify-between rounded-lg border border-slate-800 bg-slate-900/60 p-3"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-slate-400">
                    <span>{p.name}</span>
                    <span className="font-mono text-slate-500">{config.timezoneLabel}</span>
                  </div>
                  <div className="mt-1 font-mono text-2xl font-bold text-slate-50 tabular-nums">
                    {p.standarHHMM}
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-slate-400 tabular-nums">
                    Terbatas {p.terbatasHMS}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onInspectIn3D(p.terbatasHours)}
                  className="mt-3 flex items-center justify-center gap-1 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-[11px] font-medium text-amber-300 transition-colors hover:border-amber-500/70 hover:bg-amber-500/10"
                >
                  <Box className="h-3 w-3" />
                  Lihat di 3D
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Section A: Data Dasar Markaz & Waktu */}
        <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-amber-400">
            Data Dasar Markaz &amp; Koreksi Waktu
          </h3>
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono tabular-nums">
            <div className="rounded-lg border border-slate-800/80 bg-slate-900/40 p-2.5">
              <div className="text-[10px] uppercase text-slate-400">Kerendahan Ufuk (D′)</div>
              <div className="mt-1 text-sm font-semibold text-slate-100">{report.dipDMS}</div>
            </div>
            <div className="rounded-lg border border-slate-800/80 bg-slate-900/40 p-2.5">
              <div className="text-[10px] uppercase text-slate-400">Koreksi Daerah (kwd)</div>
              <div className="mt-1 text-sm font-semibold text-slate-100">{report.kwdHMS}</div>
            </div>
            <div className="rounded-lg border border-slate-800/80 bg-slate-900/40 p-2.5">
              <div className="text-[10px] uppercase text-slate-400">Perata Waktu (e)</div>
              <div className="mt-1 text-sm font-semibold text-sky-300">
                {report.equationOfTimeHMS}
              </div>
            </div>
            <div className="rounded-lg border border-slate-800/80 bg-slate-900/40 p-2.5">
              <div className="text-[10px] uppercase text-slate-400">Semi Diameter (SD)</div>
              <div className="mt-1 text-sm font-semibold text-slate-100">
                {report.semiDiameterDMS}
              </div>
            </div>
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-2.5">
              <div className="text-[10px] uppercase text-amber-400">Kulminasi (WKM)</div>
              <div className="mt-1 text-sm font-bold text-amber-300">
                {report.wkmHMS} {config.timezoneLabel}
              </div>
            </div>
          </div>
        </div>

        {/* Section B: Rincian Perhitungan Setiap Waktu Salat */}
        <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">
              Rincian Perhitungan Setiap Waktu Salat
            </h3>
            <span className="text-[11px] text-slate-400">
              Urutan sesuai Praktik Hisab Abd. Salam Nawawi (hlm. 24–35)
            </span>
          </div>

          <div className="mt-3 divide-y divide-slate-800/80">
            {report.prayers.map((p) => (
              <div key={p.id} className="py-3.5 first:pt-1 last:pb-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-baseline gap-2">
                    <h4 className="text-sm font-semibold text-slate-100">Awal {p.name}</h4>
                    <span className="font-mono text-[11px] text-slate-400">
                      ({p.gmtSampleLabel} · δ = {p.declinationDMS})
                    </span>
                  </div>
                  <div className="font-mono text-xs font-semibold text-amber-300 tabular-nums">
                    Standar: {p.standarHHMM} {config.timezoneLabel}
                  </div>
                </div>
                <p className="mt-1 text-xs text-slate-400">{p.astronomicalNote}</p>
                <div className="mt-2 space-y-1 rounded-lg border border-slate-800/90 bg-slate-950/70 p-2.5 font-mono text-[11px] text-slate-300 tabular-nums overflow-x-auto">
                  {p.formulaSteps.map((step, i) => (
                    <div key={i} className="whitespace-nowrap">
                      {step}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

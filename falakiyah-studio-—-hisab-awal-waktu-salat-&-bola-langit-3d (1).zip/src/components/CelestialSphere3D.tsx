import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Compass,
  Eye,
  Pause,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Sun,
} from 'lucide-react';
import type { HisabReport, SkyStateAtTime } from '../types/hisab';
import { computeSkyStateAtLocalTime, formatDMS, formatHMS } from '../lib/hisabEngine';

interface CelestialSphere3DProps {
  report: HisabReport;
  localHours: number;
  onChangeLocalHours: (h: number) => void;
}

const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;
const SPHERE_RADIUS = 4.2;
const GNOMON_HEIGHT = 1.15;

const CAMERA_FOV = 44;

type CameraPresetId = 'perspective' | 'gnomon' | 'meridian' | 'west_horizon';

const CAMERA_PRESETS: Record<
  CameraPresetId,
  { label: string; dir: [number, number, number]; scale: number }
> = {
  perspective: {
    label: 'Bola Langit',
    dir: [6.8, 4.2, 7.2],
    scale: 1.0,
  },
  gnomon: {
    label: 'Tongkat Istiwa',
    dir: [2.4, 2.7, 2.7],
    scale: 0.45,
  },
  meridian: {
    label: 'Sumbu Meridian',
    dir: [8.8, 1.4, 0.2],
    scale: 1.0,
  },
  west_horizon: {
    label: 'Ufuk Barat',
    dir: [6.4, 1.8, 0.5],
    scale: 1.0,
  },
};

function computeFitDistance(aspect: number, fovDeg: number, scale = 1.0): number {
  const halfFovV = (fovDeg * 0.5) * DEG2RAD;
  const halfFovH = Math.atan(Math.tan(halfFovV) * Math.max(0.45, aspect));
  const boundingRadius = SPHERE_RADIUS + 1.05;
  const distV = boundingRadius / Math.sin(halfFovV);
  const distH = boundingRadius / Math.sin(halfFovH);
  return Math.max(distV, distH) * scale;
}

function equatorialToLocalVec(
  THREE: any,
  latDeg: number,
  decDeg: number,
  hourAngleDeg: number,
  radius: number
) {
  const phi = latDeg * DEG2RAD;
  const dec = decDeg * DEG2RAD;
  const H = hourAngleDeg * DEG2RAD;

  const sinAlt = Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(H);
  const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt)));

  const yAz = -Math.cos(dec) * Math.sin(H);
  const xAz = Math.sin(dec) * Math.cos(phi) - Math.cos(dec) * Math.sin(phi) * Math.cos(H);
  const az = Math.atan2(yAz, xAz);

  const cosAlt = Math.cos(alt);
  const x = radius * cosAlt * Math.sin(az);
  const y = radius * Math.sin(alt);
  const z = -radius * cosAlt * Math.cos(az);
  return new THREE.Vector3(x, y, z);
}

function horizonToLocalVec(THREE: any, altDeg: number, azDeg: number, radius: number) {
  const alt = altDeg * DEG2RAD;
  const az = azDeg * DEG2RAD;
  const cosAlt = Math.cos(alt);
  return new THREE.Vector3(
    radius * cosAlt * Math.sin(az),
    radius * Math.sin(alt),
    -radius * cosAlt * Math.cos(az)
  );
}

function createCompassDialTexture(THREE: any): any {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const cx = size / 2;
  const cy = size / 2;

  // Slate stone radial gradient surface
  const bgGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, size * 0.49);
  bgGrad.addColorStop(0, '#161e2e');
  bgGrad.addColorStop(0.7, '#0f1623');
  bgGrad.addColorStop(1, '#0b101b');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, size, size);

  // Concentric calibration rings
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
  ctx.lineWidth = 2;
  [120, 220, 320, 420, 470].forEach((r) => {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  });

  // Cardinal crosshair (U-S and T-B)
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.28)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx, cy - 468);
  ctx.lineTo(cx, cy + 468);
  ctx.moveTo(cx - 468, cy);
  ctx.lineTo(cx + 468, cy);
  ctx.stroke();

  // Azimuth degree ticks around outer bezel
  for (let deg = 0; deg < 360; deg += 5) {
    const rad = ((deg - 90) * Math.PI) / 180;
    const isMajor = deg % 30 === 0;
    const isMed = deg % 15 === 0;
    const rOuter = 468;
    const rInner = isMajor ? 434 : isMed ? 446 : 456;
    ctx.strokeStyle = isMajor ? 'rgba(248, 250, 252, 0.72)' : 'rgba(148, 163, 184, 0.35)';
    ctx.lineWidth = isMajor ? 3 : 1.5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(rad) * rInner, cy + Math.sin(rad) * rInner);
    ctx.lineTo(cx + Math.cos(rad) * rOuter, cy + Math.sin(rad) * rOuter);
    ctx.stroke();

    if (isMajor && deg % 90 !== 0) {
      const rTxt = 408;
      ctx.save();
      ctx.translate(cx + Math.cos(rad) * rTxt, cy + Math.sin(rad) * rTxt);
      ctx.rotate(rad + Math.PI / 2);
      ctx.fillStyle = 'rgba(203, 213, 225, 0.72)';
      ctx.font = '600 18px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${deg}°`, 0, 0);
      ctx.restore();
    }
  }

  // Cardinal Indonesian/Falak labels: U (Utara), T (Timur), S (Selatan), B (Barat)
  const cardinals = [
    { label: 'U · N', angle: -Math.PI / 2, color: '#38bdf8' },
    { label: 'T · E', angle: 0, color: '#f59e0b' },
    { label: 'S · S', angle: Math.PI / 2, color: '#e2e8f0' },
    { label: 'B · W', angle: Math.PI, color: '#fb7185' },
  ];
  cardinals.forEach((c) => {
    const r = 398;
    const tx = cx + Math.cos(c.angle) * r;
    const ty = cy + Math.sin(c.angle) * r;
    ctx.fillStyle = c.color;
    ctx.font = '700 28px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(c.label, tx, ty);
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.encoding = THREE.sRGBEncoding;
  tex.needsUpdate = true;
  return tex;
}

export const CelestialSphere3D: React.FC<CelestialSphere3DProps> = ({
  report,
  localHours,
  onChangeLocalHours,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playSpeed, setPlaySpeed] = useState<number>(60); // 60 min/sec
  const [dockCollapsed, setDockCollapsed] = useState(
    () => typeof window !== 'undefined' && window.innerWidth < 768
  );
  const [showTelemetryDetail, setShowTelemetryDetail] = useState(false);
  const [showSceneMenu, setShowSceneMenu] = useState(false);
  const [showTwilightRings, setShowTwilightRings] = useState(true);
  const [showArcHelpers, setShowArcHelpers] = useState(true);
  const [showDipCone, setShowDipCone] = useState(true);
  const [webglError, setWebglError] = useState<string | null>(null);

  const skyState: SkyStateAtTime = useMemo(
    () => computeSkyStateAtLocalTime(report, localHours),
    [report, localHours]
  );

  // Refs for imperatively syncing React state into the Three.js render loop without tearing down scene
  const latestPropsRef = useRef({
    report,
    localHours,
    skyState,
    showTwilightRings,
    showArcHelpers,
    showDipCone,
    isPlaying,
    playSpeed,
  });
  latestPropsRef.current = {
    report,
    localHours,
    skyState,
    showTwilightRings,
    showArcHelpers,
    showDipCone,
    isPlaying,
    playSpeed,
  };

  const onChangeHoursRef = useRef(onChangeLocalHours);
  onChangeHoursRef.current = onChangeLocalHours;

  const sceneApiRef = useRef<{
    requestRender: () => void;
    updateAstronomyGeometry: () => void;
    jumpCamera: (preset: CameraPresetId) => void;
  } | null>(null);

  // Keyboard shortcut 'H' to toggle dock
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if (e.key === 'h' || e.key === 'H') {
        setDockCollapsed((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Initialize Three.js r128 scene once
  useEffect(() => {
    const container = mountRef.current;
    const THREE = window.THREE;
    if (!container || !THREE) {
      setWebglError('Mesin WebGL / Three.js r128 tidak tersedia.');
      return;
    }

    let renderer: any;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError('Peramban tidak mendukung konteks WebGL untuk simulasi 3D.');
      return;
    }

    const gl = renderer.getContext();
    let isSoftwareGl = false;
    try {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        const rendererName = String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '');
        isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(rendererName);
      }
    } catch {
      isSoftwareGl = false;
    }

    const rect = container.getBoundingClientRect();
    const width = Math.max(300, rect.width || container.clientWidth || 800);
    const height = Math.max(300, rect.height || container.clientHeight || 560);

    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    // Three.js r128 API: outputEncoding + sRGBEncoding
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.touchAction = 'none';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const bgColor = new THREE.Color('#07090e');
    scene.background = bgColor;
    scene.fog = new THREE.FogExp2(0x07090e, 0.018);

    // Procedural studio IBL environment (compatible with Three r128 without RoomEnvironment)
    const pmremGen = new THREE.PMREMGenerator(renderer);
    pmremGen.compileEquirectangularShader();
    const envScene = new THREE.Scene();
    envScene.background = new THREE.Color(0x0b1220);
    const envLightTop = new THREE.Mesh(
      new THREE.PlaneGeometry(14, 14),
      new THREE.MeshBasicMaterial({ color: 0xfef3c7, side: THREE.DoubleSide })
    );
    envLightTop.position.set(0, 8, 0);
    envLightTop.rotation.x = Math.PI / 2;
    envScene.add(envLightTop);
    const envLightSide = new THREE.Mesh(
      new THREE.PlaneGeometry(10, 8),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8, side: THREE.DoubleSide })
    );
    envLightSide.position.set(-8, 3, -4);
    envLightSide.lookAt(0, 0, 0);
    envScene.add(envLightSide);
    const envRT = pmremGen.fromScene(envScene, 0.04);
    scene.environment = envRT.texture;
    pmremGen.dispose();

    let currentPresetScale = CAMERA_PRESETS.perspective.scale;
    const camera = new THREE.PerspectiveCamera(CAMERA_FOV, width / height, 0.1, 120);
    const initDist = computeFitDistance(width / height, CAMERA_FOV, currentPresetScale);
    camera.position
      .set(...CAMERA_PRESETS.perspective.dir)
      .normalize()
      .multiplyScalar(initDist);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.07;
    // Disable pinch-to-zoom / wheel zoom and panning; keep central axis permanently locked at (0,0,0)
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.touches = {
      ONE: THREE.TOUCH.ROTATE,
      TWO: null,
    };
    controls.minDistance = initDist;
    controls.maxDistance = initDist;
    controls.maxPolarAngle = Math.PI * 0.92;
    controls.target.set(0, 0, 0);
    controls.update();

    // Lighting rig (Key Sun Directional + Cool Sky/Ground Hemisphere + Rim Light)
    const hemiLight = new THREE.HemisphereLight(0x60a5fa, 0x0f172a, 0.55);
    scene.add(hemiLight);

    const sunDirLight = new THREE.DirectionalLight(0xfff1d6, 2.1);
    sunDirLight.castShadow = !isSoftwareGl;
    sunDirLight.shadow.mapSize.width = 2048;
    sunDirLight.shadow.mapSize.height = 2048;
    sunDirLight.shadow.camera.near = 0.5;
    sunDirLight.shadow.camera.far = 22;
    sunDirLight.shadow.camera.left = -4.2;
    sunDirLight.shadow.camera.right = 4.2;
    sunDirLight.shadow.camera.top = 4.2;
    sunDirLight.shadow.camera.bottom = -4.2;
    sunDirLight.shadow.bias = -0.0004;
    sunDirLight.shadow.normalBias = 0.02;
    scene.add(sunDirLight);
    scene.add(sunDirLight.target);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.42);
    rimLight.position.set(-6, 5, -6);
    scene.add(rimLight);

    // Subtle ambient starfield
    const starCount = 420;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = 2 * Math.PI * u;
      const phi = Math.acos(2 * v - 1);
      const r = 24 + Math.random() * 14;
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = r * Math.cos(phi);
      starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({
      color: 0xcbd5e1,
      size: 0.09,
      transparent: true,
      opacity: 0.55,
      sizeAttenuation: true,
    });
    scene.add(new THREE.Points(starGeo, starMat));

    // --- 1. OBSERVATORY HORIZON INSTRUMENT & GNOMON (Composite Group) ---
    const observatoryGroup = new THREE.Group();
    scene.add(observatoryGroup);

    const basaltMat = new THREE.MeshStandardMaterial({
      color: 0x0d1320,
      roughness: 0.78,
      metalness: 0.15,
    });
    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.34,
      metalness: 0.85,
    });
    const darkSteelMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.5,
      metalness: 0.7,
    });

    // Lower stepped plinth
    const plinthLower = new THREE.Mesh(
      new THREE.CylinderGeometry(2.72, 2.9, 0.24, 32),
      basaltMat
    );
    plinthLower.position.y = -0.22;
    plinthLower.receiveShadow = true;
    observatoryGroup.add(plinthLower);

    // Outer brass gimbal rim around dial
    const dialBezel = new THREE.Mesh(
      new THREE.TorusGeometry(2.62, 0.045, 16, 72),
      brassMat
    );
    dialBezel.rotation.x = Math.PI / 2;
    dialBezel.position.y = -0.02;
    observatoryGroup.add(dialBezel);

    // Compass dial surface (receives gnomon shadow!)
    const dialTex = createCompassDialTexture(THREE);
    if (dialTex) {
      dialTex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    }
    const dialSurfaceMat = new THREE.MeshStandardMaterial({
      map: dialTex,
      roughness: 0.72,
      metalness: 0.08,
    });
    const dialPlate = new THREE.Mesh(
      new THREE.CylinderGeometry(2.6, 2.6, 0.08, 72),
      dialSurfaceMat
    );
    dialPlate.position.y = -0.04;
    dialPlate.receiveShadow = true;
    observatoryGroup.add(dialPlate);

    // Tongkat Istiwa (Gnomon) multi-part assembly at center
    const gnomonGroup = new THREE.Group();
    observatoryGroup.add(gnomonGroup);

    const gnomonBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.15, 0.07, 24),
      darkSteelMat
    );
    gnomonBase.position.y = 0.035;
    gnomonBase.castShadow = true;
    gnomonBase.receiveShadow = true;
    gnomonGroup.add(gnomonBase);

    const gnomonCollar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.08, 0.08, 20),
      brassMat
    );
    gnomonCollar.position.y = 0.1;
    gnomonCollar.castShadow = true;
    gnomonGroup.add(gnomonCollar);

    const gnomonRod = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.032, GNOMON_HEIGHT - 0.12, 20),
      brassMat
    );
    gnomonRod.position.y = 0.12 + (GNOMON_HEIGHT - 0.12) / 2;
    gnomonRod.castShadow = true;
    gnomonGroup.add(gnomonRod);

    const gnomonTip = new THREE.Mesh(
      new THREE.ConeGeometry(0.024, 0.09, 16),
      new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.25, metalness: 0.9 })
    );
    gnomonTip.position.y = GNOMON_HEIGHT + 0.01;
    gnomonTip.castShadow = true;
    gnomonGroup.add(gnomonTip);

    // Analytical shadow vector strip & Asar threshold ring on dial
    const analyticalShadowGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0.008, 0),
      new THREE.Vector3(0, 0.008, 0.01),
    ]);
    const analyticalShadowLine = new THREE.Line(
      analyticalShadowGeo,
      new THREE.LineBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.9 })
    );
    observatoryGroup.add(analyticalShadowLine);

    const asarRingMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.55,
    });
    const asarThresholdRing = new THREE.LineLoop(new THREE.BufferGeometry(), asarRingMat);
    observatoryGroup.add(asarThresholdRing);

    // --- 2. CELESTIAL SPHERE & ASTRONOMICAL RINGS ---
    const sphereGroup = new THREE.Group();
    scene.add(sphereGroup);

    // True Horizon ring (Ufuk Hakiki) at radius SPHERE_RADIUS
    const horizonRing = new THREE.Mesh(
      new THREE.TorusGeometry(SPHERE_RADIUS, 0.024, 12, 96),
      new THREE.MeshStandardMaterial({
        color: 0x64748b,
        roughness: 0.5,
        metalness: 0.5,
      })
    );
    horizonRing.rotation.x = Math.PI / 2;
    sphereGroup.add(horizonRing);

    // Subtle translucent horizon disc
    const horizonDisc = new THREE.Mesh(
      new THREE.RingGeometry(2.65, SPHERE_RADIUS - 0.02, 72),
      new THREE.MeshBasicMaterial({
        color: 0x1e293b,
        transparent: true,
        opacity: 0.22,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    horizonDisc.rotation.x = Math.PI / 2;
    sphereGroup.add(horizonDisc);

    // Meridian Ring (North - Zenith - South - Nadir)
    const meridianRing = new THREE.Mesh(
      new THREE.TorusGeometry(SPHERE_RADIUS, 0.02, 12, 96),
      new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        roughness: 0.4,
        metalness: 0.65,
      })
    );
    meridianRing.rotation.y = Math.PI / 2;
    sphereGroup.add(meridianRing);

    // Permanent Central Axis (Sumbu Tengah: Zenit - Pusat (0,0,0) - Nadir)
    const zenithMarker = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.085, 0),
      new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xd97706, emissiveIntensity: 0.55 })
    );
    zenithMarker.position.set(0, SPHERE_RADIUS, 0);
    sphereGroup.add(zenithMarker);

    const nadirMarker = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.075, 0),
      new THREE.MeshStandardMaterial({ color: 0x94a3b8, emissive: 0x334155, emissiveIntensity: 0.4 })
    );
    nadirMarker.position.set(0, -SPHERE_RADIUS, 0);
    sphereGroup.add(nadirMarker);

    const centralAxisGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, -SPHERE_RADIUS, 0),
      new THREE.Vector3(0, SPHERE_RADIUS, 0),
    ]);
    const centralAxisLine = new THREE.Line(
      centralAxisGeo,
      new THREE.LineBasicMaterial({ color: 0xfef08a, transparent: true, opacity: 0.32 })
    );
    sphereGroup.add(centralAxisLine);

    // Celestial Pole Axis passing permanently through center (0,0,0)
    const poleAxisGeo = new THREE.BufferGeometry();
    const poleAxisLine = new THREE.Line(
      poleAxisGeo,
      new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.38 })
    );
    sphereGroup.add(poleAxisLine);

    // Dynamic Astronomical Rings (rebuilt when config/declination/time changes)
    const dynamicGroup = new THREE.Group();
    sphereGroup.add(dynamicGroup);

    const buildCirclePoints = (ptsFn: (deg: number) => any, step = 4) => {
      const pts: any[] = [];
      for (let d = 0; d <= 360; d += step) {
        pts.push(ptsFn(d));
      }
      return pts;
    };

    // Equator Ring
    const equatorGeo = new THREE.BufferGeometry();
    const equatorLine = new THREE.Line(
      equatorGeo,
      new THREE.LineBasicMaterial({ color: 0x94a3b8, transparent: true, opacity: 0.55 })
    );
    dynamicGroup.add(equatorLine);

    // Diurnal Sun Path at declination delta
    const diurnalDayGeo = new THREE.BufferGeometry();
    const diurnalDayLine = new THREE.Line(
      diurnalDayGeo,
      new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.92 })
    );
    dynamicGroup.add(diurnalDayLine);

    // Twilight depression rings (-18 deg Isyak & -20 deg Subuh)
    const isyakRingGeo = new THREE.BufferGeometry();
    const isyakRingLine = new THREE.Line(
      isyakRingGeo,
      new THREE.LineBasicMaterial({ color: 0xa78bfa, transparent: true, opacity: 0.6 })
    );
    dynamicGroup.add(isyakRingLine);

    const subuhRingGeo = new THREE.BufferGeometry();
    const subuhRingLine = new THREE.Line(
      subuhRingGeo,
      new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.6 })
    );
    dynamicGroup.add(subuhRingLine);

    // Kerendahan Ufuk (D') depressed horizon cone/ring
    const dipRingGeo = new THREE.BufferGeometry();
    const dipRingLine = new THREE.Line(
      dipRingGeo,
      new THREE.LineBasicMaterial({ color: 0xfb7185, transparent: true, opacity: 0.72 })
    );
    dynamicGroup.add(dipRingLine);

    // Hour angle t arc (from Meridian to Sun along declination circle)
    const hourAngleGeo = new THREE.BufferGeometry();
    const hourAngleLine = new THREE.Line(
      hourAngleGeo,
      new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.85 })
    );
    dynamicGroup.add(hourAngleLine);

    // Altitude h vertical arc (from Horizon at Sun's Azimuth up/down to Sun)
    const altArcGeo = new THREE.BufferGeometry();
    const altArcLine = new THREE.Line(
      altArcGeo,
      new THREE.LineBasicMaterial({ color: 0x34d399, transparent: true, opacity: 0.88 })
    );
    dynamicGroup.add(altArcLine);

    // Solar Orb Group
    const sunOrbGroup = new THREE.Group();
    const sunCoreMat = new THREE.MeshBasicMaterial({ color: 0xfff7ed });
    const sunCore = new THREE.Mesh(new THREE.SphereGeometry(0.16, 24, 24), sunCoreMat);
    const sunHaloMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.32,
      depthWrite: false,
    });
    const sunHalo = new THREE.Mesh(new THREE.SphereGeometry(0.28, 24, 24), sunHaloMat);
    sunOrbGroup.add(sunCore);
    sunOrbGroup.add(sunHalo);
    sphereGroup.add(sunOrbGroup);

    // Dashed ray line from Sun to Gnomon tip
    const rayGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, GNOMON_HEIGHT, 0),
      new THREE.Vector3(0, 2, 0),
    ]);
    const rayLine = new THREE.Line(
      rayGeo,
      new THREE.LineBasicMaterial({ color: 0xfde68a, transparent: true, opacity: 0.42 })
    );
    sphereGroup.add(rayLine);

    // Update all dynamic astronomy geometries cleanly
    const updateAstronomyGeometry = () => {
      const { report: rep, skyState: sky, showTwilightRings: twi, showArcHelpers: arcs, showDipCone: dip } =
        latestPropsRef.current;
      const lat = rep.config.latitudeDeg;
      const dec = sky.declinationDeg;

      // Celestial Pole Axis through origin (dec = -90° to +90°)
      poleAxisGeo.setFromPoints([
        equatorialToLocalVec(THREE, lat, -90, 0, SPHERE_RADIUS),
        equatorialToLocalVec(THREE, lat, 90, 0, SPHERE_RADIUS),
      ]);

      // Celestial Equator (dec = 0)
      equatorGeo.setFromPoints(
        buildCirclePoints((h) => equatorialToLocalVec(THREE, lat, 0, h, SPHERE_RADIUS))
      );

      // Diurnal Sun Path (dec = sky.declinationDeg)
      diurnalDayGeo.setFromPoints(
        buildCirclePoints((h) => equatorialToLocalVec(THREE, lat, dec, h, SPHERE_RADIUS))
      );

      // Twilight depression rings
      isyakRingLine.visible = twi;
      subuhRingLine.visible = twi;
      if (twi) {
        const hIsyak = -rep.config.isyakDepressionDeg - rep.dipDeg;
        const hSubuh = -rep.config.subuhDepressionDeg - rep.dipDeg;
        isyakRingGeo.setFromPoints(
          buildCirclePoints((az) => horizonToLocalVec(THREE, hIsyak, az, SPHERE_RADIUS))
        );
        subuhRingGeo.setFromPoints(
          buildCirclePoints((az) => horizonToLocalVec(THREE, hSubuh, az, SPHERE_RADIUS))
        );
      }

      // Dip ring (Ufuk Mar'i): amplify visual angle slightly when D' > 0 so observer can inspect it clearly, while keeping label exact
      const hasDip = dip && rep.dipDeg > 0.001;
      dipRingLine.visible = hasDip;
      if (hasDip) {
        const visualDipDeg = Math.min(8, Math.max(1.2, rep.dipDeg * 6));
        dipRingGeo.setFromPoints(
          buildCirclePoints((az) => horizonToLocalVec(THREE, -visualDipDeg, az, SPHERE_RADIUS))
        );
      }

      // Solar orb position
      const sunVec = equatorialToLocalVec(THREE, lat, dec, sky.hourAngleDeg, SPHERE_RADIUS);
      sunOrbGroup.position.copy(sunVec);

      // Dynamic sun & atmosphere color based on solar altitude
      const alt = sky.altitudeDeg;
      if (alt > 12) {
        sunCoreMat.color.setHex(0xfffbeb);
        sunHaloMat.color.setHex(0xfbbf24);
        sunDirLight.color.setHex(0xfff3d6);
        sunDirLight.intensity = 2.2;
        bgColor.set('#0a1120');
      } else if (alt > -1) {
        sunCoreMat.color.setHex(0xfdba74);
        sunHaloMat.color.setHex(0xea580c);
        sunDirLight.color.setHex(0xfb923c);
        sunDirLight.intensity = Math.max(0.25, ((alt + 1) / 13) * 1.9);
        bgColor.set('#10111d');
      } else if (alt > -18) {
        sunCoreMat.color.setHex(0xfb7185);
        sunHaloMat.color.setHex(0x7c3aed);
        sunDirLight.intensity = 0.08;
        bgColor.set('#080b16');
      } else {
        sunCoreMat.color.setHex(0x94a3b8);
        sunHaloMat.color.setHex(0x38bdf8);
        sunDirLight.intensity = 0.04;
        bgColor.set('#05070c');
      }
      scene.background = bgColor;
      scene.fog.color.copy(bgColor);

      // Position directional sunlight toward center gnomon when sun is above horizon
      if (alt > 0.5) {
        sunDirLight.position.copy(sunVec).normalize().multiplyScalar(9);
        sunDirLight.castShadow = !isSoftwareGl;
      } else {
        sunDirLight.position.set(0, -6, 0);
        sunDirLight.castShadow = false;
      }

      // Sun-to-Gnomon ray
      rayLine.visible = arcs && alt > 0.5;
      if (rayLine.visible) {
        rayGeo.setFromPoints([new THREE.Vector3(0, GNOMON_HEIGHT, 0), sunVec]);
      }

      // Hour angle t arc (Meridian H=0 to H_sun)
      hourAngleLine.visible = arcs;
      if (arcs) {
        const hPts: any[] = [];
        const steps = 28;
        for (let i = 0; i <= steps; i++) {
          const hCur = (sky.hourAngleDeg * i) / steps;
          hPts.push(equatorialToLocalVec(THREE, lat, dec, hCur, SPHERE_RADIUS * 0.96));
        }
        hourAngleGeo.setFromPoints(hPts);
      }

      // Vertical altitude h arc (from Horizon at Sun azimuth up/down to Sun)
      altArcLine.visible = arcs;
      if (arcs) {
        const aPts: any[] = [];
        const steps = 20;
        for (let i = 0; i <= steps; i++) {
          const aCur = (alt * i) / steps;
          aPts.push(horizonToLocalVec(THREE, aCur, sky.azimuthDeg, SPHERE_RADIUS * 0.98));
        }
        altArcGeo.setFromPoints(aPts);
      }

      // Analytical Gnomon Shadow Vector & Asar Threshold Circle on the dial
      const asarShadowWorldR = Math.min(2.48, sky.asarShadowThresholdRatio * GNOMON_HEIGHT);
      asarThresholdRing.geometry.dispose();
      asarThresholdRing.geometry = new THREE.BufferGeometry().setFromPoints(
        buildCirclePoints(
          (deg) =>
            new THREE.Vector3(
              Math.cos(deg * DEG2RAD) * asarShadowWorldR,
              0.008,
              Math.sin(deg * DEG2RAD) * asarShadowWorldR
            ),
          6
        )
      );

      if (sky.gnomonShadowLengthRatio !== null && alt > 1.2) {
        analyticalShadowLine.visible = true;
        const shadowWorldLen = Math.min(2.5, sky.gnomonShadowLengthRatio * GNOMON_HEIGHT);
        const oppAzRad = ((sky.azimuthDeg + 180) % 360) * DEG2RAD;
        const sx = shadowWorldLen * Math.sin(oppAzRad);
        const sz = -shadowWorldLen * Math.cos(oppAzRad);
        analyticalShadowGeo.setFromPoints([
          new THREE.Vector3(0, 0.01, 0),
          new THREE.Vector3(sx, 0.01, sz),
        ]);
      } else {
        analyticalShadowLine.visible = false;
      }
    };

    // Camera transition state (smooth exponential damp, permanently centered at origin (0,0,0))
    let transitionActive = false;
    const desiredCamPos = camera.position.clone();

    const onControlsStart = () => {
      transitionActive = false;
    };
    controls.addEventListener('start', onControlsStart);

    // Prevent browser gesture pinch-zoom on the canvas element
    const preventGesture = (e: Event) => e.preventDefault();
    renderer.domElement.addEventListener('gesturestart', preventGesture, { passive: false });
    renderer.domElement.addEventListener('gesturechange', preventGesture, { passive: false });

    let rafId = 0;
    let renderPending = false;
    let lastTs = performance.now();

    const drawFrame = (now: number) => {
      renderPending = false;
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTs) / 1000));
      lastTs = now;

      const { isPlaying: playing, playSpeed: speed, localHours: hrs } = latestPropsRef.current;

      if (playing) {
        const nextHrs = (hrs + (dt * speed) / 60) % 24;
        onChangeHoursRef.current(nextHrs);
      }

      if (transitionActive) {
        const lambda = 7;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, desiredCamPos.x, lambda, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, desiredCamPos.y, lambda, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, desiredCamPos.z, lambda, dt);

        if (camera.position.distanceTo(desiredCamPos) < 0.015) {
          transitionActive = false;
        }
      }

      controls.target.set(0, 0, 0);
      const dampingNeedsMore = controls.update();
      renderer.render(scene, camera);

      if (playing || transitionActive || dampingNeedsMore) {
        requestRender();
      }
    };

    const requestRender = () => {
      if (!renderPending) {
        renderPending = true;
        rafId = requestAnimationFrame(drawFrame);
      }
    };

    controls.addEventListener('change', requestRender);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      cancelAnimationFrame(rafId);
      renderPending = false;
      setWebglError('Konteks WebGL terputus sementara.');
    };
    const onContextRestored = () => {
      setWebglError(null);
      updateAstronomyGeometry();
      requestRender();
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = Math.max(240, entry.contentRect.width);
        const h = Math.max(240, entry.contentRect.height);
        const aspect = w / h;
        camera.aspect = aspect;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);

        // Keep sphere exact screen-fitted on resize
        const fitDist = computeFitDistance(aspect, CAMERA_FOV, currentPresetScale);
        controls.minDistance = fitDist;
        controls.maxDistance = fitDist;
        if (camera.position.lengthSq() > 0.0001) {
          camera.position.setLength(fitDist);
        }
        desiredCamPos.setLength(fitDist);
        controls.update();
        requestRender();
      }
    });
    resizeObserver.observe(container);

    sceneApiRef.current = {
      requestRender,
      updateAstronomyGeometry: () => {
        updateAstronomyGeometry();
        requestRender();
      },
      jumpCamera: (preset: CameraPresetId) => {
        const p = CAMERA_PRESETS[preset];
        currentPresetScale = p.scale;
        const fitDist = computeFitDistance(camera.aspect, CAMERA_FOV, p.scale);
        controls.minDistance = fitDist;
        controls.maxDistance = fitDist;
        desiredCamPos.set(...p.dir).normalize().multiplyScalar(fitDist);
        transitionActive = true;
        requestRender();
      },
    };

    updateAstronomyGeometry();
    requestRender();

    return () => {
      sceneApiRef.current = null;
      cancelAnimationFrame(rafId);
      resizeObserver.disconnect();
      controls.removeEventListener('start', onControlsStart);
      controls.removeEventListener('change', requestRender);
      controls.dispose();
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);
      renderer.domElement.removeEventListener('gesturestart', preventGesture);
      renderer.domElement.removeEventListener('gesturechange', preventGesture);

      scene.traverse((obj: any) => {
        if (obj.geometry) obj.geometry.dispose();
        if (obj.material) {
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m: any) => m.dispose());
          } else {
            obj.material.dispose();
          }
        }
      });
      if (dialTex) dialTex.dispose();
      envRT.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Re-sync dynamic 3D astronomy rings & solar orb whenever inputs/time/toggles change
  useEffect(() => {
    sceneApiRef.current?.updateAstronomyGeometry();
  }, [report, localHours, showTwilightRings, showArcHelpers, showDipCone]);

  // Trigger animation loop when playback starts
  useEffect(() => {
    if (isPlaying) {
      sceneApiRef.current?.requestRender();
    }
  }, [isPlaying]);

  const prayerButtons = useMemo(() => {
    const byId = Object.fromEntries(report.prayers.map((p) => [p.id, p]));
    return [
      { id: 'subuh', label: 'Subuh', hours: byId.subuh.terbatasHours, hhmm: byId.subuh.standarHHMM },
      { id: 'terbit', label: 'Terbit', hours: report.terbitHours, hhmm: report.terbitHHMM },
      { id: 'zuhur', label: 'Zuhur', hours: byId.zuhur.terbatasHours, hhmm: byId.zuhur.standarHHMM },
      { id: 'asar', label: 'Asar', hours: byId.asar.terbatasHours, hhmm: byId.asar.standarHHMM },
      { id: 'magrib', label: 'Magrib', hours: byId.magrib.terbatasHours, hhmm: byId.magrib.standarHHMM },
      { id: 'isyak', label: 'Isyak', hours: byId.isyak.terbatasHours, hhmm: byId.isyak.standarHHMM },
    ];
  }, [report]);

  return (
    <div className="relative w-full h-full bg-[#07090e] overflow-hidden select-none touch-none">
      {/* Dedicated Three.js mount container with zero React children */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing touch-none" />

      {webglError && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#07090e] p-6 text-center">
          <div className="max-w-md rounded-lg border border-slate-800 bg-slate-950 p-6">
            <p className="text-sm font-medium text-amber-400">Simulasi 3D Tidak Aktif</p>
            <p className="mt-2 text-xs text-slate-400">{webglError}</p>
          </div>
        </div>
      )}

      {/* Top Compact HUD: Minimal single-row strip by default so 3D Bola Langit remains unobstructed */}
      <div className="pointer-events-none absolute top-2 inset-x-2 z-10 flex items-start justify-between gap-2">
        {/* Top-left: Compact 1-line telemetry chip + expandable detail card */}
        <div className="pointer-events-auto relative min-w-0">
          <button
            type="button"
            onClick={() => {
              setShowTelemetryDetail((v) => !v);
              setShowSceneMenu(false);
            }}
            className="flex items-center gap-2 rounded-lg border border-slate-800 bg-[#0b101b]/92 px-2.5 py-1.5 text-left transition-colors hover:border-slate-700"
          >
            <span className="font-mono text-[11px] font-semibold text-amber-400 tabular-nums shrink-0">
              {formatHMS(localHours, 0).slice(0, 5)} {report.config.timezoneLabel}
            </span>
            <span className="text-slate-600">·</span>
            <span className="font-mono text-[11px] tabular-nums shrink-0">
              <span className="text-slate-400">h </span>
              <span className={skyState.altitudeDeg >= 0 ? 'text-emerald-400' : 'text-sky-400'}>
                {skyState.altitudeDeg >= 0 ? '+' : ''}
                {skyState.altitudeDeg.toFixed(1)}°
              </span>
            </span>
            <span className="hidden min-[400px]:inline text-slate-600">·</span>
            <span className="hidden min-[400px]:inline font-mono text-[11px] tabular-nums shrink-0">
              <span className="text-slate-400">t </span>
              <span className="text-amber-300">
                {skyState.hourAngleDeg >= 0 ? '+' : ''}
                {skyState.hourAngleDeg.toFixed(1)}°
              </span>
            </span>
            <span className="ml-0.5 flex items-center gap-0.5 text-[10px] font-medium text-slate-400">
              <span className="hidden sm:inline">Detail</span>
              {showTelemetryDetail ? (
                <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              )}
            </span>
          </button>

          {showTelemetryDetail && (
            <div className="mt-1.5 w-[290px] sm:w-[340px] rounded-lg border border-slate-800 bg-[#0b101b]/96 px-3 py-2.5 shadow-xl">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400">
                  Posisi Matahari &amp; Bola Langit
                </span>
                <span className="font-mono text-xs font-semibold text-amber-400 tabular-nums">
                  {formatHMS(localHours, 0)} {report.config.timezoneLabel}
                </span>
              </div>
              <p className="mt-1 text-xs font-medium text-slate-200">{skyState.phaseLabel}</p>
              <div className="mt-1.5 grid grid-cols-3 gap-2 border-t border-slate-800/80 pt-1.5 font-mono text-[11px] tabular-nums">
                <div>
                  <div className="text-slate-500">Tinggi (h)</div>
                  <div className={skyState.altitudeDeg >= 0 ? 'text-emerald-400' : 'text-sky-400'}>
                    {formatDMS(skyState.altitudeDeg, 1, true)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Sudut (t)</div>
                  <div className="text-amber-300">{formatDMS(skyState.hourAngleDeg, 1, true)}</div>
                </div>
                <div>
                  <div className="text-slate-500">Azimut</div>
                  <div className="text-slate-200">{skyState.azimuthDeg.toFixed(1)}°</div>
                </div>
              </div>
              <div className="mt-1.5 flex items-center justify-between gap-2 border-t border-slate-800/80 pt-1.5 font-mono text-[11px] text-slate-400 tabular-nums">
                <span>
                  Istiwa:{' '}
                  <strong className="text-slate-200">
                    {skyState.gnomonShadowLengthRatio !== null
                      ? `${skyState.gnomonShadowLengthRatio.toFixed(2)}× H`
                      : 'Di bawah ufuk'}
                  </strong>
                </span>
                <span>Asar ≥ {skyState.asarShadowThresholdRatio.toFixed(2)}× H</span>
              </div>
            </div>
          )}
        </div>

        {/* Top-right: Desktop slim camera bar + compact mobile popover trigger */}
        <div className="pointer-events-auto relative flex flex-col items-end gap-1.5 shrink-0">
          <div className="flex items-center gap-1">
            {/* Desktop quick camera presets */}
            <div className="hidden lg:flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0b101b]/92 p-1">
              {(Object.keys(CAMERA_PRESETS) as CameraPresetId[]).map((presetKey) => (
                <button
                  key={presetKey}
                  type="button"
                  onClick={() => sceneApiRef.current?.jumpCamera(presetKey)}
                  className="rounded px-2 py-1 text-[11px] font-medium text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
                >
                  {CAMERA_PRESETS[presetKey].label}
                </button>
              ))}
              <button
                type="button"
                title="Reset Kamera"
                onClick={() => sceneApiRef.current?.jumpCamera('perspective')}
                className="rounded px-1.5 py-1 text-slate-400 transition-colors hover:bg-slate-800 hover:text-white"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowSceneMenu((v) => !v);
                setShowTelemetryDetail(false);
              }}
              className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition-colors ${
                showSceneMenu
                  ? 'border-amber-500/60 bg-amber-500/15 text-amber-300'
                  : 'border-slate-800 bg-[#0b101b]/92 text-slate-300 hover:border-slate-700 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5 text-amber-400" />
              <span className="hidden sm:inline lg:hidden">Kamera &amp; Lapisan</span>
              <span className="sm:hidden">Kamera</span>
              <span className="hidden lg:inline">Lapisan</span>
              {showSceneMenu ? (
                <ChevronUp className="h-3.5 w-3.5" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5" />
              )}
            </button>
          </div>

          {showSceneMenu && (
            <div className="w-60 rounded-lg border border-slate-800 bg-[#0b101b]/96 p-2.5 shadow-xl space-y-2.5">
              <div className="lg:hidden space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    Sudut Kamera
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      sceneApiRef.current?.jumpCamera('perspective');
                      setShowSceneMenu(false);
                    }}
                    className="flex items-center gap-1 text-[10px] text-amber-400 hover:text-amber-300"
                  >
                    <RotateCcw className="h-3 w-3" />
                    Reset
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {(Object.keys(CAMERA_PRESETS) as CameraPresetId[]).map((presetKey) => (
                    <button
                      key={presetKey}
                      type="button"
                      onClick={() => {
                        sceneApiRef.current?.jumpCamera(presetKey);
                        setShowSceneMenu(false);
                      }}
                      className="rounded border border-slate-800 bg-slate-900/80 px-2 py-1.5 text-left text-[11px] font-medium text-slate-200 transition-colors hover:border-slate-700 hover:bg-slate-800"
                    >
                      {CAMERA_PRESETS[presetKey].label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5 border-t border-slate-800/80 pt-2 lg:border-t-0 lg:pt-0">
                <span className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Lapisan Geometris
                </span>
                <div className="flex flex-col gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setShowTwilightRings((v) => !v)}
                    className={`flex items-center justify-between rounded border px-2 py-1.5 transition-colors ${
                      showTwilightRings
                        ? 'border-sky-500/40 bg-sky-500/15 text-sky-300'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <Eye className="h-3 w-3" />
                      Fajar/Syafaq (−18°/−20°)
                    </span>
                    <span className="text-[10px]">{showTwilightRings ? 'Aktif' : 'Mati'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowArcHelpers((v) => !v)}
                    className={`flex items-center justify-between rounded border px-2 py-1.5 transition-colors ${
                      showArcHelpers
                        ? 'border-amber-500/40 bg-amber-500/15 text-amber-300'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <Compass className="h-3 w-3" />
                      Busur t &amp; h
                    </span>
                    <span className="text-[10px]">{showArcHelpers ? 'Aktif' : 'Mati'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowDipCone((v) => !v)}
                    className={`flex items-center justify-between rounded border px-2 py-1.5 transition-colors ${
                      showDipCone
                        ? 'border-rose-500/40 bg-rose-500/15 text-rose-300'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span>Ufuk Mar’i (D′)</span>
                    <span className="text-[10px]">{showDipCone ? 'Aktif' : 'Mati'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Collapsible Control Dock */}
      <div className="absolute bottom-2.5 inset-x-2.5 sm:left-1/2 sm:right-auto sm:w-[calc(100%-24px)] sm:max-w-3xl sm:-translate-x-1/2 z-10">
        {dockCollapsed ? (
          <div className="mx-auto flex max-w-md items-center justify-between gap-2 rounded-lg border border-slate-800 bg-[#0b101b]/94 px-2.5 py-1.5">
            <button
              type="button"
              onClick={() => setIsPlaying((v) => !v)}
              className="flex items-center gap-1.5 rounded bg-amber-500 px-2.5 py-1 text-[11px] font-semibold text-slate-950 transition-colors hover:bg-amber-400 shrink-0"
            >
              {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
              {isPlaying ? 'Jeda' : 'Putar'}
            </button>

            <div className="min-w-0 flex-1 text-center">
              <span className="font-mono text-xs font-semibold text-slate-100 tabular-nums">
                {formatHMS(localHours, 0)}
              </span>
              <span className="hidden sm:inline text-xs text-slate-400"> · {skyState.phaseLabel}</span>
            </div>

            <button
              type="button"
              onClick={() => setDockCollapsed(false)}
              className="flex items-center gap-1 rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:border-slate-500 hover:text-white shrink-0"
            >
              <span>Waktu</span>
              <ChevronUp className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : (
          <>
            <div className="flex justify-center mb-1.5">
              <button
                type="button"
                onClick={() => setDockCollapsed(true)}
                className="flex items-center gap-1.5 rounded border border-slate-700 bg-[#0b101b]/95 px-3 py-1 text-[11px] font-medium text-slate-300 hover:border-slate-500 hover:text-white"
              >
                <ChevronDown className="h-3.5 w-3.5" />
                Sembunyikan Kontrol (H)
              </button>
            </div>

            <div className="rounded-lg border border-slate-800 bg-[#0b101b]/94 px-3 py-2.5 sm:px-4 sm:py-3">
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                <button
                  type="button"
                  onClick={() => setIsPlaying((v) => !v)}
                  className="flex items-center gap-1.5 rounded bg-amber-500 px-3 py-1.5 text-xs font-semibold text-slate-950 transition-colors hover:bg-amber-400"
                >
                  {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  {isPlaying ? 'Jeda' : 'Putar Siang-Malam'}
                </button>

                <select
                  aria-label="Kecepatan simulasi"
                  value={playSpeed}
                  onChange={(e) => setPlaySpeed(Number(e.target.value))}
                  className="rounded border border-slate-700 bg-slate-900 px-2 py-1.5 font-mono text-xs text-slate-200 focus:border-amber-500 focus:outline-none"
                >
                  <option value={20}>20 mnt/dtk</option>
                  <option value={60}>1 jam/dtk</option>
                  <option value={180}>3 jam/dtk</option>
                </select>

                <div className="flex flex-1 items-center gap-2.5 min-w-[160px]">
                  <Sun className="h-4 w-4 shrink-0 text-amber-400" />
                  <input
                    type="range"
                    min={0}
                    max={23.99}
                    step={0.01}
                    value={localHours}
                    onChange={(e) => {
                      setIsPlaying(false);
                      onChangeLocalHours(Number(e.target.value));
                    }}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <span className="font-mono text-xs text-slate-200 tabular-nums shrink-0">
                    {formatHMS(localHours, 0)}
                  </span>
                </div>
              </div>

              <div className="mt-2.5 grid grid-cols-3 sm:grid-cols-6 gap-1.5 border-t border-slate-800 pt-2.5">
                {prayerButtons.map((btn) => {
                  const isNear = Math.abs(localHours - btn.hours) < 0.08;
                  return (
                    <button
                      key={btn.id}
                      type="button"
                      onClick={() => {
                        setIsPlaying(false);
                        onChangeLocalHours(btn.hours);
                      }}
                      className={`rounded border px-1.5 py-1.5 text-center transition-colors ${
                        isNear
                          ? 'border-amber-500/80 bg-amber-500/15 text-amber-200'
                          : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      <div className="text-[10px] uppercase tracking-wider text-slate-400">
                        {btn.label}
                      </div>
                      <div className="font-mono text-xs font-semibold tabular-nums">{btn.hhmm}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

import React, { useMemo, useState } from 'react';
import { BookOpen, Calculator, Compass, Download, Globe, Table2 } from 'lucide-react';
import type { HisabInputConfig } from './types/hisab';
import {
  DEFAULT_CONFIG,
  calculateHisab,
  formatLatDMS,
  formatLonDMS,
  generateMonthlySchedule,
} from './lib/hisabEngine';
import {
  buildScheduleCSV,
  downloadHisabDocx,
  downloadHisabZipBundle,
} from './lib/exportReport';
import { RincianHisabView } from './components/RincianHisabView';
import { CelestialSphere3D } from './components/CelestialSphere3D';
import { TabelKerjaView } from './components/TabelKerjaView';
import { TeoriRumusView } from './components/TeoriRumusView';

type ActiveTab = 'hisab' | 'simulasi3d' | 'tabel' | 'teori';

export default function App() {
  const [config, setConfig] = useState<HisabInputConfig>(DEFAULT_CONFIG);
  const [activeTab, setActiveTab] = useState<ActiveTab>('hisab');
  const [simHours, setSimHours] = useState<number>(14.79); // ~Asar on 2 Sept 2006
  const [exportBusy, setExportBusy] = useState(false);
  const [exportNotice, setExportNotice] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);

  const report = useMemo(() => calculateHisab(config), [config]);
  const schedule = useMemo(() => generateMonthlySchedule(config, 30), [config]);

  const handleInspectIn3D = (localHours: number) => {
    setSimHours(localHours);
    setActiveTab('simulasi3d');
  };

  const handleExportDocx = async () => {
    setExportBusy(true);
    setExportNotice(null);
    try {
      await downloadHisabDocx(report, schedule);
      setExportNotice({
        type: 'ok',
        text: `Laporan DOCX untuk ${config.locationName} (${config.dateISO}) berhasil diunduh.`,
      });
    } catch (err: any) {
      setExportNotice({
        type: 'err',
        text: err?.message || 'Gagal membuat dokumen DOCX.',
      });
    } finally {
      setExportBusy(false);
    }
  };

  const handleExportZip = async () => {
    setExportBusy(true);
    setExportNotice(null);
    try {
      await downloadHisabZipBundle(report, schedule);
      setExportNotice({
        type: 'ok',
        text: `Paket arsip ZIP (DOCX + CSV + JSON + Rumus) berhasil diunduh.`,
      });
    } catch (err: any) {
      setExportNotice({
        type: 'err',
        text: err?.message || 'Gagal mengemas arsip ZIP.',
      });
    } finally {
      setExportBusy(false);
    }
  };

  const handleExportCsv = () => {
    const csv = buildScheduleCSV(report, schedule);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Jadwal_Salat_30Hari_${config.dateISO}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setExportNotice({
      type: 'ok',
      text: 'Jadwal 30 hari (CSV) berhasil diunduh.',
    });
  };

  const navItems: { id: ActiveTab; label: string; shortLabel: string; icon: React.ReactNode }[] = [
    { id: 'hisab', label: 'Hisab & Rincian', shortLabel: 'Hisab', icon: <Calculator className="h-3.5 w-3.5" /> },
    { id: 'simulasi3d', label: 'Bola Langit 3D', shortLabel: '3D Langit', icon: <Globe className="h-3.5 w-3.5" /> },
    { id: 'tabel', label: 'Tabel & Jadwal', shortLabel: 'Tabel', icon: <Table2 className="h-3.5 w-3.5" /> },
    { id: 'teori', label: 'Teori & Arsitektur', shortLabel: 'Teori', icon: <BookOpen className="h-3.5 w-3.5" /> },
  ];

  const is3DTab = activeTab === 'simulasi3d';

  return (
    <div
      className={`${
        is3DTab ? 'h-dvh overflow-hidden' : 'min-h-screen'
      } bg-[#07090e] text-slate-100 flex flex-col`}
    >
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 shrink-0 border-b border-slate-800/90 bg-[#07090e]/95">
        <div className="mx-auto flex h-12 md:h-14 max-w-[1440px] items-center justify-between gap-4 md:gap-8 px-3.5 sm:px-6">
          {/* Zone 1: Brand */}
          <div className="flex items-center gap-2.5 shrink-0">
            <Compass className="h-5 w-5 text-amber-400" />
            <span className="font-serif text-base font-semibold tracking-tight text-slate-50 whitespace-nowrap">
              Falakiyah Studio
            </span>
          </div>

          {/* Zone 2: Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-slate-800 text-amber-300'
                      : 'text-slate-400 hover:bg-slate-900 hover:text-slate-100'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action */}
          <div className="shrink-0">
            <button
              type="button"
              disabled={exportBusy}
              onClick={handleExportDocx}
              className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 sm:px-3.5 py-1.5 text-xs font-semibold text-slate-950 whitespace-nowrap transition-colors hover:bg-amber-400 disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Unduh Laporan DOCX</span>
              <span className="sm:hidden">DOCX</span>
            </button>
          </div>
        </div>

        {/* Mobile Clean 4-Column Navigation Bar */}
        <nav className="grid grid-cols-4 border-t border-slate-800/80 md:hidden">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center gap-0.5 py-1.5 text-[11px] font-medium transition-colors ${
                  active
                    ? 'bg-slate-800/80 text-amber-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.icon}
                <span>{item.shortLabel}</span>
              </button>
            );
          })}
        </nav>
      </header>

      {/* Secondary Context Telemetry Ribbon (Unboxed metadata separated by ·) */}
      <div className="shrink-0 border-b border-slate-800/70 bg-[#0a0e17]">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-2 px-3.5 sm:px-6 py-1 text-[11px] font-mono text-slate-400 tabular-nums">
          <div className="truncate">
            <strong className="text-slate-200">{config.locationName}</strong>
            <span className="hidden sm:inline">
              {' '}· {formatLatDMS(config.latitudeDeg)} · {formatLonDMS(config.longitudeDeg)} ·{' '}
              {config.elevationM} m
            </span>
            {' '}· {config.dateISO} ({config.timezoneLabel})
          </div>
          <div className="shrink-0">
            WKM <strong className="text-amber-300">{report.wkmHMS}</strong>
            <span className="hidden sm:inline">
              {' '}· D′ <strong className="text-slate-200">{report.dipDMS}</strong> · e{' '}
              <strong className="text-sky-300">{report.equationOfTimeHMS}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Export Status Notice */}
      {exportNotice && (
        <div className="mx-auto w-full max-w-[1440px] shrink-0 px-4 sm:px-6 pt-3">
          <div
            className={`flex items-center justify-between rounded-lg border px-3.5 py-2 text-xs ${
              exportNotice.type === 'ok'
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                : 'border-rose-500/40 bg-rose-500/10 text-rose-200'
            }`}
          >
            <span>{exportNotice.text}</span>
            <button
              type="button"
              onClick={() => setExportNotice(null)}
              className="ml-4 text-xs underline opacity-80 hover:opacity-100"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {/* Main Content Workspace */}
      <main
        className={
          is3DTab
            ? 'w-full flex-1 min-h-0 overflow-hidden'
            : 'mx-auto w-full max-w-[1440px] flex-1 px-4 sm:px-6 py-4'
        }
      >
        {activeTab === 'hisab' && (
          <RincianHisabView
            config={config}
            report={report}
            onChangeConfig={setConfig}
            onInspectIn3D={handleInspectIn3D}
          />
        )}
        {activeTab === 'simulasi3d' && (
          <CelestialSphere3D
            report={report}
            localHours={simHours}
            onChangeLocalHours={setSimHours}
          />
        )}
        {activeTab === 'tabel' && (
          <TabelKerjaView
            report={report}
            schedule={schedule}
            onExportDocx={handleExportDocx}
            onExportZip={handleExportZip}
            onExportCsv={handleExportCsv}
            exportBusy={exportBusy}
          />
        )}
        {activeTab === 'teori' && <TeoriRumusView report={report} />}
      </main>
    </div>
  );
}
